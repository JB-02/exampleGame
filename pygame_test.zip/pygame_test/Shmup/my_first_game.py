import pygame
import random
import os

game_folder = os.path.dirname(__file__)
img_folder = os.path.join(game_folder, "../img")
image_width = 67
image_height = 94

WIDTH = 600  # Breite des Spielfensters
HEIGHT = 600  # Höhe des Spielfensters
FPS = 65000  # Frames per Second

# Farben diffinieren
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (150, 0, 255)
BLUE = (0, 0, 255)



class Player (pygame.sprite.Sprite):
    def __init__(self, speed=[5]):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(os.path.join(img_folder, "p1_jump.png")).convert()
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH / 2, HEIGHT / 2)
        self.speed = speed



    # def update(self):
    #     self.rect.x += 5
    #     if self.rect.left > WIDTH:
    #         self.rect.right = 0

    # def update(self):
    #     delta = 5
    #     self.rect.x += delta
    #     if self.rect.x >= 600:
    #         delta -5
    #     elif self.rect.x < 0:
    #         delta = 5

    def update(self):
        if(self.rect.x < 0) or (self.rect.x > WIDTH - image_width):
            self.speed[0] *= -1

        self.rect.x = self.rect.x + self.speed[0]

# initalisiere pygame und ertselle ein Fenster
pygame.init()
pygame.mixer.init()  # für sound
screen = pygame.display.set_mode ((WIDTH, HEIGHT))
pygame.display.set_caption("My Game")
clock = pygame.time.Clock()
all_sprites = pygame.sprite.Group()
player = Player()
all_sprites.add(player)

#Game Loop
running = True
while running:

    clock.tick(FPS)

    for event in pygame.event.get():
        # check for closing window
        if event.type == pygame.QUIT:
            running = False

    #Update
    all_sprites.update()

    screen.fill (GREEN) #DRAW / render
    all_sprites.draw(screen)

    pygame.display.flip() # nach drawing flip alles

pygame.quit()